﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace practics
{
    public class Program
    {
        public static void Main()
        {
            Console.WriteLine();
            var db = new DebtorContext();
            var list2 = new List<Debtor>();
            //2) rhyta.com ve ya dayrep.com domenlerinde emaili olan borclulari cixartmag
            //list2 = db.Debtors.Where(d => d.Email.EndsWith("rhyta.com") || d.Email.EndsWith("dayrep.com")).ToList();

            //3) Yashi 26-dan 36-ya qeder olan borclulari cixartmag
            //list2 =db.Debtors.Where(d=> DateTime.Now.Year - d.BirthDate.Year >= 26&& DateTime.Now.Year - d.BirthDate.Year <= 36).ToList();

            //4) Borcu 5000 - den cox olmayan borclularic cixartmag
            //list2 = db.Debtors.Where(d => d.Debt < 5000).ToList();

            //5) Butov adi 18 simvoldan cox olan ve telefon nomresinde 2 ve ya 2 - den cox 7 reqemi olan borclulari cixartmaq
            //list2 = db.Debtors.Where( d => (d.FullName.Length > 18) && (d.Phone.Count(c => c == '7') > 2)).ToList();

            //7
            //list2 = db.Debtors.Where(debtor => (debtor.BirthDate.Month == 12) || (debtor.BirthDate.Month == 1) || (debtor.BirthDate.Month == 2)).ToList();
            //8) Borcu, umumi borclarin orta borcunnan cox olan borclulari cixarmaq ve evvel familyaya gore sonra ise meblegin azalmagina gore sortirovka etmek

            //9
            //list2 = db.Debtors.Where(debtor => !(debtor.Phone.Contains('8'))).ToList();

            //11)Adinda ve familyasinda hec olmasa 3 eyni herf olan borclularin siyahisin cixarmaq ve onlari elifba sirasina gore sortirovka elemek
            //var list = db.Debtors.OrderByDescending(debtor => LetterCounter(debtor.FullName) >= 3).OrderBy(debtor => debtor.FullName).ToList();


            //13)borclulardan en coxu hansi ilde dogulubsa hemin ili cixartmaq
            //List<DateTime> list = new List<DateTime>();
            //foreach (var item in db.Debtors)
            //{
            //    list.Add(item.BirthDate);
            //}
            //var year = list.GroupBy(year => year.Year).OrderByDescending(group => group.Count()).First().Key;
            //Console.WriteLine(year);

            //14)Borcu en boyuk olan 5 borclunun siyahisini cixartmaq
            //List<Debtor> list = db.Debtors.OrderByDescending(debtor => debtor.Debt).Take(5).ToList();
            //foreach (var item in list)
            //{
            //    Console.WriteLine(item);
            //}

            //15)Butun borcu olanlarin borcunu cemleyib umumi borcu cixartmaq
            //int cem = db.Debtors.Sum(debtor => debtor.Debt);
            //Console.WriteLine(cem);


            //16)2ci dunya muharibesin gormush borclularin siyahisi cixartmaq
            //List<Debtor> list = db.Debtors.Where(debtor => (debtor.BirthDate.Year >= 1941 && debtor.BirthDate.Year <= 1945)).ToList();
            //foreach (var item in list)
            //{
            //    Console.WriteLine(item);
            //}

            //18)Nomresinde tekrar reqemler olmayan borclularin ve onlarin borcunun meblegin cixartmaq
            //var list = db.Debtors.Where(debtor => numbercheck(debtor.Phone)).ToList();
            //foreach (var item in list)
            //{
            //    Console.WriteLine(item);
            //}

            //19)Tesevvur edek ki,butun borclari olanlar bugunden etibaren her ay 500 azn pul odeyecekler.Oz ad gunune kimi borcun oduyub qurtara bilenlerin siyahisin cixartmaq
            //List<Debtor> list = db.Debtors.Where(debtor => ((DateTime.Now.Month - debtor.BirthDate.Month) * 6000) > debtor.Debt).ToList();
            //foreach (var item in list)
            //{
            //    Console.WriteLine(item);
            //}



            //20)Adindaki ve familyasindaki herflerden "smile" sozunu yaza bileceyimiz borclularin siyahisini cixartmaq
            //List<Debtor> list = db.Debtors.Where(debtor =>
            //((debtor.FullName.Contains('s') || debtor.FullName.Contains('S')) && (debtor.FullName.Contains('m') || debtor.FullName.Contains('M')) && (debtor.FullName.Contains('i') || debtor.FullName.Contains('I')) && (debtor.FullName.Contains('l') || debtor.FullName.Contains('L')) && (debtor.FullName.Contains('e')) || debtor.FullName.Contains('E'))).ToList();
            //foreach (var item in list)
            //{
            //    Console.WriteLine(item);
            //}


            foreach (var item in list2)
            {
                Console.WriteLine("Id:\t\t" + item.Id);
                Console.WriteLine("Full Name:\t" + item.FullName);
                Console.WriteLine("Birth Date:\t" + item.BirthDate.ToString());
                Console.WriteLine("Phone:\t\t" + item.Phone);
                Console.WriteLine("Email:\t\t" + item.Email);
                Console.WriteLine("Address:\t" + item.Address);
                Console.WriteLine("Debt:\t\t" + item.Debt);
                Console.WriteLine("-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --");
            }

        }
        public  static int LetterCounter(string name)
        {
            string newName = name.ToLower();
            int counter = 0;

            for (global::System.Int32 i = 0; i < name.Length; i++)
            {
                for (global::System.Int32 j = 0; j < name.Length; j++)
                {
                    if (newName[j] == newName[i]) counter++;
                }
                if (counter >= 3) return counter;
                else counter = 0;
            }
            return 0;
        }
        private static bool numbercheck(string number)
        {
            int index = 1;
            string newnum;
            number = number.Replace("", "");
            for (int i = 0; i < number.Length; i++)
            {
                newnum = number.Substring(index);
                if (newnum.Contains(number[i])) return false;
                index++;
            }
            return true;
        }
    }
}
