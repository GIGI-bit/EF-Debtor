﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practics
{
    public class Debtor
    {
        public int Id { get; set; }
        public string  FullName {  get; set; }
        public DateTime BirthDate {  get; set; }
        public string Phone {  get; set; }
        public string Email {  get; set; }
        public string Address {  get; set; }
        public int Debt {  get; set; }
        public Debtor()
        {
            
        }
        public Debtor(int id,string fullname, DateTime birthDay, string phone, string email, string address, int debt)
        {
            this.Id= id;
            this.FullName = fullname;
            this.BirthDate = birthDay;
            this.Phone = phone;
            this.Email = email;
            this.Address = address;
            this.Debt = debt;
        }
    }
}
